//AUTHOR:		JIANGLIN FU 
//EDIT DATE:		2017-02-04
//STUDENT ID:		*** 
//COMPUTING ID:		***

#include <stdio.h>
#include <string.h>
#include <stdlib.h> // for malloc
#include <time.h>
#include <errno.h>
#include <stdio.h>
#include <stdbool.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <signal.h>
#define cmd_length 200

int prompt() {
	char buffer[cmd_length];
	char* curDir = getcwd(buffer, cmd_length);
	printf("%s >>", curDir);
	//printf("arlene's shell>>");
	return 0;
}

//------------------------token the input command------------------------//
char** tokenize(char buffer[]) {
	int i = 0;
	char** token = malloc(200*sizeof(char));
	//char *token[100];
	char* temp = strtok(buffer,"  '\t\n\a\r") ;

	while (temp!=NULL) { //store new line
		//-------------------correct version1
		token[i] = temp;
		temp = strtok(NULL,"  '\t\n\a\r");
		/*printf("%d %s \n", i, token[i]);*/
		i++;
		//-------------------correct version2
		//token[i++] = temp;
		//token[i] = NULL;
		//temp = strtok(NULL," '\t") ;
	}
	//printf("test print");
	//token[i] = NULL;
	//for (int j=0; j<i ;j++){
	//	printf("%d %s", j, token[j]);
	//	printf("\n");}
	token[i] = NULL;
	return token;
}

//tenHistory(inputLineIndex, hisMatrix);
//------------------------Print the history matrix------------------------//
void tenHistory(int inputLineIndex, char hisMatrix[200][200]){
    int start, end =0;
    if (inputLineIndex < 10)
        end = inputLineIndex - 1;
    else{
        start = inputLineIndex - 10;
        end = inputLineIndex - 1;}
    for (int i = start; i <= end; i++){
        char** command1 = tokenize(hisMatrix[i]);
        //printf("%d: ", i);
        for (int j=0; command1[j] != NULL; j++)
            //-------------------为什么啊锕锕锕锕锕锕锕锕！！！------------------//
            //printf("%d : %s\n", j, command1[j]); //j won't go up! don't know why
            printf("%s\n", command1[j]);
        //printf("%d lalala", i);外面的i是好的，但里面的j不会increment
        }
    }
}


int main() {
	//basic signals handling (disable)
	signal (SIGINT, SIG_IGN);  //ctrl-c
	signal (SIGTSTP, SIG_IGN); //ctrl-z
	signal (SIGQUIT, SIG_IGN); //ctrl-'\'

	//for history matrix info update		
	int inputLineIndex=0;
	char hisMatrix[200][200];

	while (true) {		
		pid_t childPid; 

		//for type_prompt, initialization
		prompt();
        
		char buffer[200];
		char** command;

        //Ctrl+D on Unixy platforms is EOF. If you are getting each char, you can check to see if you got EOF.
        //EOF encountered, ctrl d pressed
        if ( fgets(buffer, 200, stdin) == NULL )
        {
            printf("CTRL-D countered.\n");
            exit(0);
        }
        else{
            if (strcmp(buffer, "\n")!=0){
                command = tokenize(buffer);
                
                /*//-----------------testing1----------------//
                printf("I got here\n");
                for (int j=0;command[j] != NULL ;j++)
                    printf("%d %s\n", j, command[j]);
                printf("finish print testing\n");
                //-----------------testing1----------------//
                printf("%s\n",command[0]); 
        //wo zhi dao le! zhe li zhi hou you ge NULL!!!!!!! ("\n")
        //er qie! zhe shi yin wei ru guo zhi da yi ge word, na token[i++] jiu shi \n le!
                bool a = strcmp(command[0], "exit");
                printf("%d\n", a);
                //-----------------testing2----------------//*/
                
                
                //add every input command into the history matrix
                inputLineIndex++;
                strcpy(hisMatrix[inputLineIndex-1], buffer);
                
                if (command[0] == NULL){
                    continue;
                    printf("c\n");}
                //here must be "else if", otherwise the internal command will run second time at "execvp(command[0], command)"
                else if (strcmp(command[0], "exit")==0){
                    printf("byebye\n");
                    exit(0);}
                else if(strcmp(command[0], "pwd")==0){
                    char buffer[cmd_length];
                    char* curDir = getcwd(buffer, cmd_length);
                    printf("%s\n", curDir);}
                else if (strcmp(command[0], "cd")==0)
                    chdir(command[1]);
                else if (strcmp(command[0], "history") == 0)
                    tenHistory(inputLineIndex, hisMatrix);
                else{
                    childPid = fork();
                    if (childPid < 0) {
                        perror("fork() failed: ");
                        printf("Errno: %d\n", errno);
                        exit(EXIT_FAILURE);}
                    else if (childPid == 0) { // child process
                            //execvp(command, args including command) 
                        execvp(command[0], command);
                        exit(0);}
                    else { // parent process
                        int status;
                        if (waitpid(childPid, &status, WUNTRACED) == -1) {
                            perror("waitpid() failed: ");
                            printf("Errno: %d\n", errno);
                            exit(EXIT_FAILURE);}
                         }
                     }
               }//for if (strcmp(buffer, "\n")!=0)
            }//for else()
    }//for while(true)
     return 0 ;
}




//version2
/*	while (true) {		
		pid_t childPid; 

		prompt();

		char buffer[200];
		fgets(buffer, 200, stdin);

		char** command;
		if (strcmp(buffer, "\n")!=0){
			command = tokenize(buffer);
			for (int j=0;command[j] != NULL ;j++){
				printf("%d %s", j, command[j]);
				printf("\n");}
			if (strcmp(command[0], "exit")==0){
				printf("byebye\n");
				exit(0);}
			if(strcmp(command[0], "pwd")==0){
				char buffer[cmd_length];
				char* curDir = getcwd(buffer, cmd_length);
				printf("%s", curDir);}
			else{
				childPid = fork();
				if (childPid < 0) {
					perror("fork() failed: ");
					printf("Errno: %d\n", errno);
					exit(EXIT_FAILURE);}
				else if (childPid == 0) { // child process
				    	//execvp(command, args including command) 
					execvp(command[0], command);
					exit(0);}
				else { // parent process
					int status;
					if (waitpid(childPid, &status, WUNTRACED) == -1) {
						perror("waitpid() failed: ");
						printf("Errno: %d\n", errno);
						exit(EXIT_FAILURE);}
				     }
			     }
		   }
	  }
*/



//version 1
		/*if (strcmp(buffer, "\n")!=0) //if buffer contains sth...
		{
		    char** command = tokenize(buffer);
		    if (strcmp(command[0], "exit")==0){
			printf("byebye\n");
			exit(0);}
		    else 
			{
			childPid = fork();
			if (childPid < 0) {
			    perror("fork() failed: ");
			    printf("Errno: %d\n", errno);
			    exit(EXIT_FAILURE);}
			else if (childPid == 0) { // child process
			    //execvp(command, args including command) 
			    execvp(command[0], command);
			    exit(0);}
			else 
			    { // parent process
			    int status;
			    if (waitpid(childPid, &status, WUNTRACED) == -1) {
				perror("waitpid() failed: ");
				printf("Errno: %d\n", errno);
				exit(EXIT_FAILURE);}
			     }
		    	}
		}*/	
